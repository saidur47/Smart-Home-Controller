CREATE PROCEDURE `register`(`uname` VARCHAR(45), `upassword` TEXT, `uemail` VARCHAR(100), `ucgid` INT(11),
                            `ucode` VARCHAR(10))
  BEGIN

Declare userCount  INT;
DECLARE newUserId INT;
Set @userCount = 0;
set @newUserId = 0;

IF Exists ( Select id From `smart_home_control`.`client_group` where `cgid` = ucgid and `activation`= ucode ) THEN
		
        Select @userCount = Count(*) from `smart_home_control`.`client_credential` where `smart_home_control`.`client_credential`.`cgid` = ucgid ;
		
        Set	@newUserId = (ucgid*100 )+( @userCount+1);
		
        INSERT INTO `smart_home_control`.`client_credential`
		(
		`userid`,
		`username`,
		`password`,
		`email`,
		`cgid`,
		`usertype`,
		`activation_status`)
		VALUES
		(
		@newUserId,
		uname,
		upassword,
		uemail,
		ucgid,
		cast(1 as binary),
		1);
        
END IF;

Select @newUserId as 'NewUserID';

END