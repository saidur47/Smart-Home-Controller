CREATE PROCEDURE `sp_client_register`(`uname` VARCHAR(45), `upassword` TEXT, `uemail` VARCHAR(100), `ucgid` INT(11),
                                      `ucode` VARCHAR(10))
  BEGIN
/*
Declare userCount  INT;
Set userCount = 0;

DECLARE newUserId INT;
set newUserId = 0;
*/
IF Exists ( Select id From `smart_home_control`.`client_group` where `cgid` = ucgid and `activation`= ucode ) THEN
		
  /*       Select Count(*) from `smart_home_control`.`client_credential` where `smart_home_control`.`client_credential`.`cgid` = ucgid  INTO userCount;
		
      Set	newUserId = (ucgid*100 )+( userCount+1);*/
		Set	newID = (ucgid + 1);
  
  INSERT INTO `smart_home_control`.`client_credential`
		(
		`userid`,
		`username`,
		`password`,
		`email`,
		`cgid`,
		`usertype`,
		`activation_status`)
		VALUES
		(
		newID,
		uname,
		upassword,
		uemail,
		ucgid,
		1,
		1);
       
	ELSE
     SET newID = -1;
END IF;
SELECT @newID as NewID;
END